define({ 

	/**
    * This method is responsible for handling the login success event
    * This method will be invoked in the custom event exposed by login component
    **/
	loginSuccessHandler: function() {
      kony.print("Entering into AuthenticationMA frmLoginController loginSuccessHandler");
      //alert("Login success");
      var navigationConfig = {"context": this, "params": {"loginSuccess": true}};
      var navigationManager = kony.mvc.getNavigationManager();
      navigationManager.navigate(navigationConfig);
      kony.print("Exiting out of AuthenticationMA frmLoginController loginSuccessHandler");
    },
  

	/**
    * This method is responsible for handling the login failure event
    * This method will be invoked in the custom event exposed by login component
    **/
	loginFailureHandler: function() {
      kony.print("Entering into AuthenticationMA frmLoginController loginFailureHandler");
      alert("Login failed");
      kony.print("Exiting out of AuthenticationMA frmLoginController loginFailureHandler");
    }
  
 });