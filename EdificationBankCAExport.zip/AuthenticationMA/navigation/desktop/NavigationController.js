define({
  handleLoginSuccessNavigation: function (data) {
    if (!data) return;
    
    if (data.loginSuccess) {
      return {
        "appName": "AccountsMA",
        "friendlyName": "frmAccounts"
      };
    }
    
    return null;
  }
});