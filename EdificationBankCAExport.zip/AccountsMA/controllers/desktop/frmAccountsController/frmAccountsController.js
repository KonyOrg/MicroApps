define({ 


  /**
  * This function is responsible for fetching the accounts 
  * by invoking the integration service
  **/
  fetchAccounts: function() {
    kony.print("Entering into AccountsMA frmAccountsController fetchAccounts");
    var integrationService = kony.sdk.getCurrentInstance().getIntegrationService("AccountsService");
    integrationService.invokeOperation("getAccountsForCustomer", {}, {}, this.fetchAccountsSuccesscallback.bind(this), this.fetchAccountsFailurecallback.bind(this));
    kony.print("Exiting out of AccountsMA frmAccountsController fetchAccounts");
  },
  
  /**
  * This function is responsible for handle the success event 
  * of accounts integration service call
  **/
  fetchAccountsSuccesscallback: function(response) {
    kony.print("Entering into AccountsMA frmAccountsController fetchAccountsSuccesscallback");
    this.view.segAccounts.widgetDataMap = {"lblData":"arrangementId","lblSectionHeader":"lblSectionHeader"};
    if (null !== response) {
      if (response.opstatus === 0) {
        if (response.body !== null) {
          var accountsGroupedIntoCategories = [];
          accountsGroupedIntoCategories.push([{"lblSectionHeader":"Current Accounts"},response.CurrentAccData]);
          accountsGroupedIntoCategories.push([{"lblSectionHeader":"Savings Accounts"},response.SavingsAccData]);
          accountsGroupedIntoCategories.push([{"lblSectionHeader":"Mortgage Accounts"},response.AAMortgageData]);
          accountsGroupedIntoCategories.push([{"lblSectionHeader":"Current Accounts with OD"},response.CurrentAccWithODData]);
          this.view.segAccounts.setData(accountsGroupedIntoCategories);
        }
      } else{
        alert ("Error in fabric layer while executing AccountsService getAccountsForCustomer: "+JSON.stringify(response));
      }
    } else {
      alert ("No respose from fabric");
    }
    kony.print("Exiting out of AccountsMA frmAccountsController fetchAccountsSuccesscallback");
  },
  
  /**
  * This function is responsible for handle the failure event 
  * of accounts integration service call
  **/
  fetchAccountsFailurecallback: function(failure) {
    kony.print("Entering into AccountsMA frmAccountsController fetchAccountsFailurecallback");
    alert("AccountsService getAccountsForCustomer failed: "+JSON.stringify(failure));
    kony.print("Exiting out of AccountsMA frmAccountsController fetchAccountsFailurecallback");
  }

});